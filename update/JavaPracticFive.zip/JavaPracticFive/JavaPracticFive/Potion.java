public class Potion{
    private String name;
    private int strengthEffect;
    private int intelligenceEffect;

    public Potion(String name, int strengthEffect, int intelligenceEffect){
        this.name = name;
        this.strengthEffect = strengthEffect;
        this.intelligenceEffect = intelligenceEffect;
    }

    public void apply(Hero hero){
        int newStrength = hero.getStrength() + strengthEffect;
        hero.setStrength(newStrength);

        int newIntelligence = hero.getIntelligence() + intelligenceEffect;
        hero.setIntelligence(newIntelligence);

        System.out.println(hero + " выпил " + this);
    }

    @Override
    public String toString() {
        return name + " (сила: " + strengthEffect + ", интеллект: " + intelligenceEffect + ")";
    }

}    