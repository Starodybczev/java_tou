import java.util.ArrayList;
import java.util.Scanner;
import inventory.*;


public class Main {
     public static void main(String[] args){
        Scanner user = new Scanner(System.in);

        System.out.println("Введи имя героя");
        String name = user.nextLine();

        System.out.print("Введите силу героя (0–100): ");
        int strength = user.nextInt();

        System.out.print("Введите интеллект героя (0–100): ");
        int intelligence = user.nextInt();

        Hero hero = new Hero(name, strength, intelligence);
        System.out.println("\n🎉 Герой создан: " + hero);

        Inventary<Potion> potions = new Inventary<>();
        potions.add(new Potion("Зелье силы", 5, 0));
        potions.add(new Potion("Зелье разума", 0, 5));
        potions.add(new Potion("Эликсир мудрости", 3, 3));
        potions.add(new Potion("Зелье яда", -10, -5));

        potions.forEach(el -> el.apply(hero));

        System.out.println("\n🎯 Итоговые характеристики: " + hero);

        user.close();
    }    
}
