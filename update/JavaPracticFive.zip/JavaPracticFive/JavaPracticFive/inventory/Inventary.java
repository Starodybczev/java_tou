package inventory;
import java.util.*;
import java.util.function.Consumer;

public class Inventary<E> {
    private final List<E> items = new ArrayList<>();

    public void add(E item){
        items.add(item);
    }
    public E get(int index){
        return items.get(index);
    }
    public void remove(int index){
         items.remove(index);
    }
    public int size(){
        return items.size();
    }
    public boolean isEmpty(){
        return items.isEmpty();
    }
    public void clear(){
        items.clear();
    }
    public void forEach(Consumer<? super E> action){
        items.forEach(action);
    }

}
