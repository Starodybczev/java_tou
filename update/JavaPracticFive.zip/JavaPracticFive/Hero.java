public class Hero {

    private String name; // имя
    private int strength; // сила
    private int intelligence; // интилект

    // конструктор
    public Hero(String name, int strength, int intelligence){
        this.name = name;
        this.strength = strength;
        this.intelligence = intelligence;
    }

    public String getName(){
        return name;
    }

    public int getStrength() {
        return strength;
    }

    public int getIntelligence() {
        return intelligence;
    }


    public void setStrength(int strength) {
        if (strength < 0) {
            this.strength = 0;
        } else if (strength > 100) {
            this.strength = 100;
        } else {
            this.strength = strength;
        }
    }


    public void setIntelligence(int intelligence) {
        if (intelligence < 0) {
            this.intelligence = 0;
        } else if (intelligence > 100) {
            this.intelligence = 100;
        } else {
            this.intelligence = intelligence;
        }
    }

    @Override
    public  String toString(){
        return name + " [Сила: " + strength + ", Интеллект: " + intelligence + "]";
    }
}
