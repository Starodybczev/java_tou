package AbstractClass;

import Interfaces.*;

public abstract class Hero {
    protected int hp = 100;
    protected AttackStrategy attackStrategy;

    public abstract void attack();
    public int getHp() { return hp; }
    public void takeDamage(int dmg) { hp -= dmg; }
}