package AbstractClass;

public abstract class Monster {
    protected int hp = 80;
    public abstract void MonsterAttack();
    public int getHp() { return hp; }
    public void takeDamage(int damage) { this.hp -= damage; }
}