package Items;

import AbstractClass.Hero;

public class Potion implements Item {
    @Override
    public void apply(Hero hero) {
        hero.takeDamage(-20); // лечим
        System.out.println("🧪 Зелье восстановило здоровье!");
    }
}
