package Items;

import AbstractClass.Hero;

public class GreaterPotion extends Potion {
    @Override
    public void apply(Hero hero) {
        hero.takeDamage(-50);
        System.out.println("💖 Мощное зелье полностью восстановило здоровье!");
    }
}
