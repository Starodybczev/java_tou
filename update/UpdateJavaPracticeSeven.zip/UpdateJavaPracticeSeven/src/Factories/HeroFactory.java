package Factories;
import AbstractClass.Hero;
import Heros.*;

public class HeroFactory {
    public static Hero createHero(String type) {
        return switch (type.toLowerCase()) {
            case "warrior" -> new Warrior();
            case "mage" -> new Mage();
            case "archer" -> new Archer();
            default -> throw new IllegalArgumentException("Unknown hero type");
        };
    }
}
