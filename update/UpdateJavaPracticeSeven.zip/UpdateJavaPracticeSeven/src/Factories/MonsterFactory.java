package Factories;
import AbstractClass.Monster;
import Monsters.*;
import java.util.Random;

public class MonsterFactory {
    public static Monster createRandomMonster() {
        return switch (new Random().nextInt(3)) {
            case 0 -> new Goblin();
            case 1 -> new Skeletron();
            case 2 -> new Dragon();
            default -> new Goblin();
        };
    }
}
