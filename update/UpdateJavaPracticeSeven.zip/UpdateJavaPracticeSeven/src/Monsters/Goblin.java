package Monsters;
import AbstractClass.Monster;

public class Goblin extends Monster {

    @Override
    public void MonsterAttack() {
        System.out.println("👹 Goblin swings a club!");
    }
    
}
