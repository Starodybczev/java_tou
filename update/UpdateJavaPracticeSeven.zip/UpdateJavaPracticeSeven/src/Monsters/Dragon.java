package Monsters;
import AbstractClass.Monster;
import Exceptions.DragonFireException;


public class Dragon extends Monster {

    @Override
    public void MonsterAttack() {
        try {
            breatheFire();
        } catch (DragonFireException e) {
            System.out.println("🔥 Ошибка при атаке дракона: " + e.getMessage());
        }
    }

    private void breatheFire() throws DragonFireException {
        System.out.println("🐉 Dragon unleashes fiery breath!");

        if (Math.random() < 0.3) {
            throw new DragonFireException("🔥 Дракон промахнулся! Огонь ушёл в небо!");
        }
    }
    
}
