import AbstractClass.Hero;
import AbstractClass.Monster;
import Exceptions.LowHealthException;
import Factories.HeroFactory;
import Factories.MonsterFactory;
import Items.*;
import Utils.BattleTemplate;

import java.util.*;

public class Game {

    private final Scanner scanner = new Scanner(System.in);
    private final Random random = new Random();

    public void start() {
        System.out.println("🏰 Добро пожаловать в подземелье!");
        System.out.println("---------------------------------");

        Hero hero = selectHero();
        Monster monster = selectMonster();

        System.out.println("\n⚡ В первой комнате вас ждёт " + monster.getClass().getSimpleName() + "!");

        List<Item> inventory = createInventory();

        startBattleLoop(hero, monster, inventory);

        scanner.close();
    }

    // ------------------ ЛОГИКА ВЫБОРА ГЕРОЯ ------------------
    private Hero selectHero() {
        Hero selectedHero = null;

        while (selectedHero == null) {
            System.out.println("\nВыберите героя:");
            System.out.println("1. ⚔️ Воин (Warrior)");
            System.out.println("2. 🔮 Маг (Mage)");
            System.out.println("3. 🏹 Лучник (Archer)");
            System.out.print("> Ваш выбор: ");

            switch (scanner.nextLine().trim()) {
                case "1" -> selectedHero = HeroFactory.createHero("warrior");
                case "2" -> selectedHero = HeroFactory.createHero("mage");
                case "3" -> selectedHero = HeroFactory.createHero("archer");
                default -> System.out.println("❌ Неверный выбор! Попробуйте снова.");
            }
        }

        System.out.println("Вы выбрали: " + selectedHero.getClass().getSimpleName() + "!");
        return selectedHero;
    }

    // ------------------ ЛОГИКА ВЫБОРА МОНСТРА ------------------
    private Monster selectMonster() {
        Monster selectedMonster = null;

        while (selectedMonster == null) {
            System.out.println("\nХотите выбрать монстра или случайного?");
            System.out.println("1. Выбрать монстра вручную");
            System.out.println("2. Случайный монстр");
            System.out.print("> Ваш выбор: ");

            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1" -> {
                    System.out.println("\nДоступные монстры:");
                    System.out.println("1. Goblin 👹");
                    System.out.println("2. Skeleton 💀");
                    System.out.println("3. Dragon 🐉");
                    System.out.print("> Кого выбираете: ");

                    switch (scanner.nextLine().trim()) {
                        case "1" -> selectedMonster = new Monsters.Goblin();
                        case "2" -> selectedMonster = new Monsters.Skeletron();
                        case "3" -> selectedMonster = new Monsters.Dragon();
                        default -> System.out.println("❌ Такого монстра нет!");
                    }
                }
                case "2" -> selectedMonster = MonsterFactory.createRandomMonster();
                default -> System.out.println("❌ Неверный выбор! Попробуйте снова.");
            }
        }
        return selectedMonster;
    }

    // ------------------ ИНВЕНТАРЬ ------------------
    private List<Item> createInventory() {
        List<Item> inventory = new ArrayList<>();
        inventory.add(new Potion());
        inventory.add(new GreaterPotion());
        return inventory;
    }

    // ------------------ ЦИКЛ БОЯ ------------------
    private void startBattleLoop(Hero hero, Monster monster, List<Item> inventory) {
        try {
            BattleTemplate battle = new BattleTemplate() {
                @Override
                protected void heroTurn(Hero hero) {
                    while (true) {
                        System.out.println("\nВыберите действие:");
                        System.out.println("1. Атаковать");
                        System.out.println("2. Использовать предмет");
                        System.out.println("3. Убежать");

                        String choice = scanner.nextLine().trim();

                        switch (choice) {
                            case "1" -> {
                                hero.attack();
                                monster.takeDamage(25);
                                return;
                            }
                            case "2" -> {
                                if (inventory.isEmpty()) {
                                    System.out.println("🎒 Рюкзак пуст!");
                                } else {
                                    Item item = inventory.remove(0);
                                    System.out.println("Вы используете: " + item.getClass().getSimpleName());
                                    item.apply(hero);
                                }
                                return;
                            }
                            case "3" -> {
                                if (random.nextBoolean()) {
                                    System.out.println("🏃‍♂️ Вы успешно убежали!");
                                    System.exit(0);
                                } else {
                                    System.out.println("❌ Не удалось убежать!");
                                    return;
                                }
                            }
                            default -> System.out.println("❌ Неверный выбор!");
                        }
                    }
                }

                @Override
                protected void monsterTurn(Monster monster) {
                    System.out.println("\n" + monster.getClass().getSimpleName() + " атакует!");
                    monster.MonsterAttack();
                    hero.takeDamage(15);
                    System.out.println("Ваш HP: " + hero.getHp());
                }
            };

            while (hero.getHp() > 0 && monster.getHp() > 0) {
                battle.startBattle(hero, monster);
                System.out.println("\n❤️ HP героя: " + hero.getHp());
                System.out.println("💀 HP монстра: " + monster.getHp());
            }

        } catch (LowHealthException e) {
            System.out.println("💀 " + e.getMessage());
        }
    }
}
