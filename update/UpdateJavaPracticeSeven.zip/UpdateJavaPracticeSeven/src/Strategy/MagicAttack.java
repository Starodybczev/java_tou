package Strategy;
import Interfaces.*;

public class MagicAttack implements AttackStrategy  {
    
    @Override
    public void attack() {
        System.out.println("Attacking with magic spells!");
    }
    
}
