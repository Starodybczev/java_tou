package fabric;

import characters.Character;
import characters.CharacterFactory;
import characters.Mage;

public class MageFactory extends CharacterFactory {
    @Override
    public Character createCharacter(String name){
        return new Mage(name);
    }
}
