package interfaces;

public interface  GameObserver {
    void onEvent(String event);
}
