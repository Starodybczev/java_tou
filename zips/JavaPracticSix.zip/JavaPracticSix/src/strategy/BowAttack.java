package strategy;

import characters.Character;
import interfaces.AttackStrategy;

public class BowAttack implements AttackStrategy{
    @Override
    public void attack(Character attacker, Character target){
        int baseDamage = 8;
        int poisonDamage = 5;


        target.takeDamage(baseDamage + poisonDamage);
        attacker.notifyObservers(attacker.getName() + " отравил врага! Урон: " + (baseDamage + poisonDamage));
    }
}
