package strategy;
import characters.Character;
import interfaces.AttackStrategy;

public class MagicAttack implements AttackStrategy {
    @Override
    public void attack(Character attacker, Character target) {
       int damage = 20;
       int selfDamage = 5;

       target.takeDamage(damage);
       attacker.takeDamage(selfDamage);
       attacker.notifyObservers(attacker.getName() + " использовал магию: враг -"  + damage + " HP, сам -" + selfDamage + " HP");
    }
}
