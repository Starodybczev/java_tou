package strategy;
import characters.Character;
import interfaces.AttackStrategy;

public class MeleeAttack implements AttackStrategy {

	@Override
	public void attack(Character attacker, Character target) {
		int damage = 15;
        target.takeDamage(damage);
       attacker.notifyObservers(attacker.getName() + " ударил врага мечом на " + damage + " урона!");
	}
}
