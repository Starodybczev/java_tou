package characters;

import interfaces.AttackStrategy;
import interfaces.GameObserver;
import java.util.ArrayList;
import java.util.List;

public abstract class Character {
    protected String name;
    protected int health;
    protected AttackStrategy attackStrategy;
    private List<GameObserver> observers = new ArrayList<>();


    public Character(String name, int health, AttackStrategy attackStrategy){
        this.name = name;
        this.health = health;
        this.attackStrategy = attackStrategy;
    }

    public String getName(){
        return name;
    }

    public int getHealth(){
        return health;
    }




   public void performAttack(Character enemy) {
        if (attackStrategy != null && this.isAlive()) {
            attackStrategy.attack(this, enemy);
        } else {
            notifyObservers(name + " не может атаковать!");
        }
    }

    public void takeDamage(int damage) {
        health -= damage;
        notifyObservers(name + " получил " + damage + " урона. Здоровье: " + health);
        if (health <= 0) {
            notifyObservers(name + " пал в бою!");
        }
    }

    public void addObserver(GameObserver observer) {
        observers.add(observer);
    }

    public void notifyObservers(String event) {
        for (GameObserver obs : observers) {
            obs.onEvent(event);
        }
    }

    public boolean isAlive() {
        return health > 0;
    }
}
