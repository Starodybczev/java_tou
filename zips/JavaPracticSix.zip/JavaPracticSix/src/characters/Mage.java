package characters;

import strategy.MagicAttack;

public class Mage extends Character {
    public Mage(String name){
        super(name, 90, new MagicAttack());
    }
}
