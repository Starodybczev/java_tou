
import characters.*;
import fabric.*;
import java.util.Random;
import java.util.Scanner;
import observer.BattleLog;

public class Game{
     public static void main(String[] args){
        CharacterFactory factory;
        Scanner user = new Scanner(System.in);

        System.out.println("Выберите класс персонажа: 1 - Воин, 2 - Маг, 3 - Лучник");
        int choice = user.nextInt();

        System.out.print("Введите имя героя: ");
        String name = user.nextLine();

        
        switch(choice){
            case 1: 
                factory = new WarriorFactory();
            case 2: 
                factory = new MageFactory();
            case 3:
                factory = new ArcherFactory();
            default:{
                System.out.println("Неверный выбор. По умолчанию выбран Воин.");
                factory = new WarriorFactory();
            }            
        }
        characters.Character player = factory.createCharacter(name);
        characters.Character enemy = new Warrior("Орк");

        BattleLog log = new BattleLog();
        player.addObserver(log);
        enemy.addObserver(log);

        System.out.println("Бой начинается между " + player.getName() + " и " + enemy.getName());

        Random rand = new Random();
        while (player.isAlive() && enemy.isAlive()) {
            if (rand.nextBoolean()) {
                player.performAttack(enemy);
            } else {
                enemy.performAttack(player);
            }
            System.out.println(player.getName() + " HP: " + player.getHealth());
            System.out.println(enemy.getName() + " HP: " + enemy.getHealth());
            System.out.println("----------------------------");
        }

        if (player.isAlive()) {
            System.out.println(player.getName() + " победил!");
        } else {
            System.out.println(enemy.getName() + " победил!");
        }
    }

}
