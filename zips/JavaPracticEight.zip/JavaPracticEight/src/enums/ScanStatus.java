package src.enums;

public enum ScanStatus {
    READY("🟡 Готов"),
    RUNNING("🔵 Сканируется"),
    DONE("🟢 Завершён");

    private final String label;

    ScanStatus(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
