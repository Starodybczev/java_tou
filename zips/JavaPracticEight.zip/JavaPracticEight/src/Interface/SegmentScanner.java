package src.Interface;

public interface  SegmentScanner<T> {
    long processSegment(T[] data, int start, int end);
}
