package src.core;
import java.util.concurrent.Callable;
import src.Interface.*;

public class ScannerTask<T extends Number> implements Callable<ScanResult> {
    private final int id;
    private final int start;
    private final int end;
    private final SegmentScanner<T> scanner;
    private final T[] data;

    public ScannerTask(int id, T[] data, int start, int end, SegmentScanner<T> scanner) {
        this.id = id;
        this.data = data;
        this.start = start;
        this.end = end;
        this.scanner = scanner; 
    }

    @Override
    public ScanResult call() {
        long sum = 0;
        int anomalies = 0;

        for (int i = start; i < end; i++) {
            long value = data[i].longValue();
            sum += value;
            if (value > 9000) anomalies++;
        }

        System.err.printf("Task #%d обработал [%d–%d) → Сумма: %d, Аномалий: %d%n",
                id, start, end, sum, anomalies);

        return new ScanResult(anomalies, sum);
    }
}
