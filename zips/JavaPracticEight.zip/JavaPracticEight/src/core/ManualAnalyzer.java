package src.core;

import java.util.concurrent.*;

public class ManualAnalyzer {

    public static long run(Integer[] data, int size, int segments) throws InterruptedException {
        int part = size / segments;
        CyclicBarrier barrier = new CyclicBarrier(segments, 
            new Runnable() {
                public void run() {
                    System.out.println("[ИИ-координатор] Все детекторы завершили фазу 1. Начинаем фазу 2.");
                }
            }
        );

        Thread[] threads = new Thread[segments];
        long start = System.currentTimeMillis();

        for (int i = 0; i < segments; i++) {
            final int id = i + 1;
            final int from = i * part;
            final int to = (i == segments - 1) ? size : from + part;

            threads[i] = new Thread(new Runnable() {
                public void run() {
                    long sum = 0;
                    int anomalies = 0;
                    for (int j = from; j < to; j++) {
                        long v = data[j];
                        sum += v;
                        if (v > 9000) anomalies++;
                    }
                    System.out.println("[Детектор-" + id + "] Фаза 1 завершена. Сумма=" + sum + ", Аномалий=" + anomalies);
                    try { barrier.await(); } catch (Exception e) {}
                    long norm = sum / (anomalies + 1);
                    System.out.println("[Детектор-" + id + "] Фаза 2 завершена. Нормализованная сумма=" + norm);
                }
            });
            threads[i].start();
        }

        for (Thread t : threads) t.join();
        return System.currentTimeMillis() - start;
    }
}
