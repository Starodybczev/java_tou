package src.core;

public class ScanResult {
    private final long sum;
    private final int anomalies;


    public ScanResult(int anomalies, long sum) {
        this.anomalies = anomalies;
        this.sum = sum;
    }


    public long getSum(){
        return sum;
    }

    public int getAnomalies(){
        return anomalies;
    }

    @Override
    public String toString() { 
        return "Сумма = " + sum + ", Аномалий = " + anomalies;
    }

}
