package src.core;

import src.AbstractClass.AbstractScanner;

public class IntSegmentScanner extends AbstractScanner<Integer> {
    
    public IntSegmentScanner(Integer[] data) {
        super(data);
    }

    @Override
    public long processSegment(Integer[] data, int start, int end) {
        long sum = 0;
        for (int i = start; i < end; i++) {
            sum += data[i];
        }
        return sum;
    }
}
