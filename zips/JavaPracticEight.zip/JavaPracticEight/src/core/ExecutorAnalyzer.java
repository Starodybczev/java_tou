package src.core;

import java.util.*;
import java.util.concurrent.*;

public class ExecutorAnalyzer {

    public static long run(Integer[] data, int size, int segments) throws Exception {
        int part = size / segments;
        ExecutorService pool = Executors.newFixedThreadPool(segments);
       List<Future<ScanResult>> results = new ArrayList<>();

        long start = System.currentTimeMillis();

        for (int i = 0; i < segments; i++) {
            final int from = i * part;
            final int to = (i == segments - 1) ? size : from + part;
            results.add(pool.submit(new Callable<ScanResult>() {
                @Override
                public ScanResult call() {
                    long sum = 0;
                    int anomalies = 0;
                    for (int j = from; j < to; j++) {
                        long val = data[j];
                        sum += val;
                        if (val > 9000) anomalies++;
                    }
                    return new ScanResult(anomalies, sum);
                }
            }));
        }

        long totalSum = 0;
        int totalAnom = 0;
        for (Future<ScanResult> f : results) {
            ScanResult r = f.get();
            totalSum += r.getSum();
            totalAnom += r.getAnomalies();
        }

        pool.shutdown();
        System.out.println("[ИИ] ExecutorService завершил работу. Сумма=" + totalSum + ", Аномалий=" + totalAnom);
        return System.currentTimeMillis() - start;
    }
}
