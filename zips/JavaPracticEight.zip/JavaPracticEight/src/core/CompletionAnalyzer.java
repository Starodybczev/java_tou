package src.core;

import java.util.concurrent.*;

public class CompletionAnalyzer {

    public static long run(Integer[] data, int size, int segments) throws Exception {
        int part = size / segments;
        ExecutorService pool = Executors.newFixedThreadPool(segments);
         CompletionService<ScanResult> service = new ExecutorCompletionService<>(pool);

        long start = System.currentTimeMillis();

        for (int i = 0; i < segments; i++) {
            final int id = i + 1;
            final int from = i * part;
            final int to = (i == segments - 1) ? size : from + part;

            service.submit(new Callable<ScanResult>() {
                @Override
                public ScanResult call() {
                    long sum = 0;
                    int anomalies = 0;
                    for (int j = from; j < to; j++) {
                        long val = data[j];
                        sum += val;
                        if (val > 9000) anomalies++;
                    }
                    System.out.println("[Центральный ИИ] Получен отчёт от Детектора-" + id +
                                       ": сумма=" + sum + ", аномалий=" + anomalies);
                    return new ScanResult(anomalies, sum);
                }
            });
        }

        long totalSum = 0;
        int totalAnom = 0;
        for (int i = 0; i < segments; i++) {
            Future<ScanResult> future = service.take();
            ScanResult r = future.get();
            totalSum += r.getSum();
            totalAnom += r.getAnomalies();
        }

        pool.shutdown();
        System.out.println("[ИИ] CompletionService завершил работу. Сумма=" + totalSum + ", Аномалий=" + totalAnom);
        return System.currentTimeMillis() - start;
    }
}

