package src.AbstractClass;

import src.Interface.SegmentScanner;

public abstract class AbstractScanner<T> implements SegmentScanner<T> {
    protected final T[] data;

    public AbstractScanner(T[] data) {
        this.data = data;
    }

    @Override
    public abstract long processSegment(T[] data, int start, int end);

}
