import java.util.*;
import src.core.*;

public class Main {
    public static void main(String[] args) throws Exception {
        final int SIZE = 100_000;
        final int SEGMENTS = 20;
        Integer[] numbers = new Integer[SIZE];
        Random rnd = new Random();

        for (int i = 0; i < SIZE; i++) {
            numbers[i] = rnd.nextInt(10_000);
        }

        System.out.println();
        System.out.println("╔════════════════════════════════════════════╗");
        System.out.println("║        СИСТЕМА АНАЛИЗА ИИ - СТАРТ         ║");
        System.out.println("╚════════════════════════════════════════════╝");
        System.out.println();

        long t1 = ManualAnalyzer.run(numbers, SIZE, SEGMENTS);
        long t2 = ExecutorAnalyzer.run(numbers, SIZE, SEGMENTS);
        long t3 = CompletionAnalyzer.run(numbers, SIZE, SEGMENTS);

        System.out.println();
        System.out.println("╔════════════════════════════════════════════╗");
        System.out.println("║          [ИИ-Аналитик] Итоги замеров       ║");
        System.out.println("╠════════════════════════════════════════════╣");
        System.out.println("║  Ручные потоки     : " + t1 + " мс");
        System.out.println("║  ExecutorService   : " + t2 + " мс");
        System.out.println("║  CompletionService : " + t3 + " мс");
        System.out.println("╚════════════════════════════════════════════╝");
    }
}
