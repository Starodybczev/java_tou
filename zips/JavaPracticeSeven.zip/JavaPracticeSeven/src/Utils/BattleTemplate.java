package Utils;

import AbstractClass.Hero;
import AbstractClass.Monster;
import Exceptions.LowHealthException;

public abstract class BattleTemplate {
    public final void startBattle(Hero hero, Monster monster) throws LowHealthException {
        System.out.println("⚔️ Битва начинается!");
        heroTurn(hero);
        monsterTurn(monster);
        checkHp(hero, monster);
    }

    protected abstract void heroTurn(Hero hero);
    protected abstract void monsterTurn(Monster monster);

    private void checkHp(Hero hero, Monster monster) throws LowHealthException {
        if (hero.getHp() <= 0)
            throw new LowHealthException("💀 Герой погиб! HP = " + hero.getHp());
        else if (monster.getHp() <= 0)
            System.out.println("✅ Монстр побеждён!");
    }
}
