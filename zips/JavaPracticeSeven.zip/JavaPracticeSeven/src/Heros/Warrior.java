package Heros;
import AbstractClass.Hero;
import Strategy.MeleeAttack;

public class Warrior extends Hero  {

    public Warrior() { this.attackStrategy = new MeleeAttack(); }

    @Override
    public void attack() { 
        attackStrategy.attack();
    }
}
