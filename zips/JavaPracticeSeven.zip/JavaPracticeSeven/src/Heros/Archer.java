package Heros;
import AbstractClass.Hero;
import Strategy.RangeAttack;

public class Archer extends Hero {

    public Archer() { this.attackStrategy = new RangeAttack(); }
    
    @Override
    public void attack() {
        attackStrategy.attack();
    }
    
}
    