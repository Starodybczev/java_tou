package Heros;
import AbstractClass.Hero;
import Strategy.MagicAttack;

public class Mage extends Hero  {

    public Mage() { this.attackStrategy = new MagicAttack(); }

    @Override
    public void attack() { 
        attackStrategy.attack();
    }
}
