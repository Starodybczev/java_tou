package Items;
import AbstractClass.Hero;

public interface Item {
    void apply(Hero hero);
}
