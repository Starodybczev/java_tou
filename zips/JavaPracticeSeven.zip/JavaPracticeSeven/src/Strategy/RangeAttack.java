package Strategy;
import Interfaces.*;

public class RangeAttack implements AttackStrategy {
    
    @Override
    public void attack() {
        System.out.println("Attacking with ranged weapons!");
    }
    
}
