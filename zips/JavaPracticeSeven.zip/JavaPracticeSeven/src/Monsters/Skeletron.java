package Monsters;
import AbstractClass.Monster;

public class Skeletron extends Monster {

    @Override
    public void MonsterAttack() {
        System.out.println("💀 Skeletron slashes with its bony arms!");
    }
    
}
