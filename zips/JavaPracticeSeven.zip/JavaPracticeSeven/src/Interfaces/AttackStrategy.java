package Interfaces;

public interface AttackStrategy {
    void attack();
}
