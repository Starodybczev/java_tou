package Exceptions;

public class DragonFireException extends Exception {
    public DragonFireException(String message) {
        super(message);
    }
}
